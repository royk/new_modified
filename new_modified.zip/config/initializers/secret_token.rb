# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
NewModified::Application.config.secret_token = '5f64b848343f434354eae878124c2f9adb802a04f2c1c627986a14873e3907f6f7731e2b069940b6279e807fef9385673cc5bf484c7efc0802e8f03e26680e57'
