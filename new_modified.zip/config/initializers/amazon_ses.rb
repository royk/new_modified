ActionMailer::Base.add_delivery_method :ses, AWS::SES::Base,
  :access_key_id     => 'AKIAIYTX6MYQZSV7ZX3A',
  :secret_access_key => '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'