Recaptcha.configure do |config|
  config.public_key  = '6LddbdkSAAAAADlikZS4jdTsKbbzyL8Ywaf8VNTW'
  config.private_key = '6LddbdkSAAAAACaUVpmS-Pr5yflKMEaVzBE2EafC'
end