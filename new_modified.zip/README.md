[![Build Status](https://secure.travis-ci.org/royk/new_modified.png?branch=master)](https://travis-ci.org/royk/new_modified)
[![Code Climate](https://codeclimate.com/badge.png)](https://codeclimate.com/github/royk/new_modified)
[![Coveralls](https://coveralls.io/repos/royk/new_modified/badge.png?branch=master)] (https://coveralls.io/repos/royk/new_modified/badge.png?branch=master)
new_modified
============

New community site for modified.in
