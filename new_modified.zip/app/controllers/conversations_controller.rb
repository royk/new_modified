class ConversationsController < ApplicationController

	def show
	end
end