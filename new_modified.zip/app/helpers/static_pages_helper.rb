module StaticPagesHelper
	
end
